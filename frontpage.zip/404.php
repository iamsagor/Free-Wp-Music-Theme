
<?php get_header() ?>
<! - -------------Content------------- -->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block03">
			<div class="col-2-3">
				<div class="wrap-col">
					<div class="box">
						<h1>Soory Your content Not founsd in our Server</h1>
						<h2>You Should gotoa	<a href="<?php bloginfo('home') ?>">Homepage</a> </h2>
						<mark>Sorry Didnot found it</mark>
					</div>
					
				</div>
			</div>
			<div class="col-1-3">
				<div class="wrap-col">
					<?php dynamic_sidebar('righttop') ?>
			</div>
		</div>
	</div>
</section>
<?php get_footer() ?>