﻿<?php get_header() /*Template Name:Contact page*/ ?>

<!--------------Content------------- -->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block03">
			<div class="col-2-3">
				<div class="wrap-col">

				<?php 
					
					 while(have_posts()):the_post() ?>
						<article>
							<?php the_post_thumbnail() ?>
							<h2><?php the_title() ?></h2>
							<div class="info">[By <?php the_author(); ?> on <?php the_time('M d Y g:i a') ?> with <?php comments_popup_link('no cmnt','1 cmnt','% comments','','') ?>]</div>
							<p><?php the_content() ?></p>												
						</article>
				<?php endwhile;?>


				
				</div>
			</div>
			<div class="col-1-3">
				<div class="wrap-col">
					<?php dynamic_sidebar('contactside') ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer() ?>