<!-- - - ------------Footer------------ -- -->
<footer>
	<div class="wrap-footer zerogrid">
		<div class="row block09">
			<?php dynamic_sidebar('footerside');
			global $zboom ?>
		</div>
		
		<div class="row copyright">
			<p>Copyright © 2013 - <a href="<?php echo $zboom['footer-link'] ?>"><?php echo $zboom['footertext'] ?></a> by <a href="http://<?php echo $zboom['author-link'] ?>" target="_blank"><?php echo $zboom['author'] ?></a></p>
		</div>
	</div>
</footer>

<script>
	(function($){

		$(function () {
		  $("#slider").responsiveSlides({
			auto: true,
			pager: false,
			nav: true,
			speed: 500,
			maxwidth: 962,
			namespace: "centered-btns"
		  });
		});
	})(jQuery);

		
	</script>

<?php wp_footer()?>
</body></html>