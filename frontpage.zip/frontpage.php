﻿<?php get_header() ?>


<?php 
/*
	Template Name:Front Page
*/


 ?>


<div class="featured">
	<div class="wrap-featured zerogrid">
		<div class="slider">
			<div class="rslides_container">
				<ul class="rslides" id="slider">
				<?php $slider= new WP_Query(array(
					'post_type'=>'myslider'
					)) ;

					 while($slider->have_posts()):$slider->the_post() ?>

					<li><?php the_post_thumbnail() ?></li>

				<?php endwhile; ?>

				</ul>
			</div>
		</div>
	</div>
</div>

<!--------------Content------------- -->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block01">
			<?php $boxpost=new WP_Query(array(
				'post_type'=> 'boxpost',
				'posts_per_page'=>3
			));
			while($boxpost->have_posts()):$boxpost->the_post()?>

			<div class="col-1-3">
				<div class="wrap-col box">
					<h2><?php the_title() ?></h2>
					<p><?php readmore(10) ?></p>
					<div class="more"><a href="<?php the_permalink() ?>">[...]</a></div>
				</div>
			</div>
		<?php endwhile; ?>

		</div>
		<div class="row block02">
			<div class="col-2-3">
				<div class="wrap-col">
					<div class="heading"><h2>Latest Blog</h2></div>
				<?php 
					$postquery=get_query_var('paged');
					$mypost=new WP_Query(array(
						'page_name'=>'blog',
						'posts_per_page'=>5,
						'paged'=>$postquery
					));
				 ?>

			<?php if($mypost->have_posts()):

				while($mypost->have_posts()):$mypost->the_post() ?>
					<article class="row">
						<div class="col-1-3">
							<div class="wrap-col">
							<?php 
								if ( has_post_thumbnail() ) {
								    the_post_thumbnail();
								}
								else {
								    echo '<img src="' . get_bloginfo( 'stylesheet_directory' ) 
								        . '/images/thumbnail-default.jpg" />';
								}
							 ?>
							</div>
						</div>
						<div class="col-2-3">
							<div class="wrap-col">
								<h2><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h2>
								<div class="info">By Admin on December 01, 2012 with <a href="#">01 Commnets</a></div>
								<?php readmore(20) ?>
								<a href="<?php the_permalink() ?>">Read more</a>
							</div>
						</div>
					</article>
				<?php endwhile;
			 endif;?>	
					
				</div>
			</div>
			<div class="col-1-3">
				<div class="wrap-col">
					<?php dynamic_sidebar('rightside') ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer() ?>