<?php 

function themecore(){
	add_theme_support('custom-header');
	add_theme_support('title-tag');
	add_theme_support('post-thumbnails');
	add_theme_support('post-thumbnails');
	set_post_thumbnail_size( 250, 250 );
	register_nav_menus(array(
		'mainmenu'=>'Main Menu',
		'footermenu'=>'Footer Menu'
	));
	register_post_type('myslider',array(
		'labels'=>array(
			'name'=>'Sliders',
			'add_new_item'=>'New image add'
		),
		'public'=>true,		
		'supports'=>array('title','thumbnail'),
		'menu_icon'   => 'dashicons-welcome-view-site'
	));
	register_post_type('boxpost',array(
		'labels'=>array(
			'name'=>'Featured Post',
			'add_new_item'=>'Add a nice and attactive Post here'
		),
		'public'=>true,
		'supports'=>array('title','editor','tag'),
		'menu_icon'=>'dashicons-editor-paste-text'
	));
	register_post_type('albumpic',array(
		'labels'=>array(
			'name'=>'Album Post',
			'add_new_item'=>'Notun item jog koro'
		),
		'public'=>true,
		'supports'=>array('title','thumbnail'),
		'menu_icon'=>'dashicons-editor-expand'
	));
	register_post_type('gallerypost',array(
		'labels'=>array(
			'name'=>'Gallery Photo',
			'add_new_item'=>'Add new Gallery photo'
		),
		'public'=>true,
		'supports'=>array('title','thumbnail'),
		'menu_icon'=>'dashicons-format-gallery'
	));
}


add_action('after_setup_theme','themecore');



function zoomsidebar(){
	register_sidebar(array(
		'name'=>'Right Sidebar',
		'description'=>'you can here from sidebar',
		'id'=>'rightside',
		'before_widget'=>'<div class="box">',
		'after_widget'=>'</div></div>',
		'before_title'=>'<div class="heading"><h2>',
		'after_title'=>'</h2></div><div class="content">'
	));
	register_sidebar(array(
		'name'=>'Footer Sidebar',
		'description'=>'footer side bar added from here',
		'id'=>'footerside',
		'before_widget'=>'<div class="col-1-4"><div class="wrap-col"><div class="box">',
		'after_widget'=>'</div></div></div></div>',
		'before_title'=>'<div class="heading"><h2>',
		'after_title'=>'</h2></div><div class="content">'
	));
	register_sidebar(array(
		'name'=>'Contact Sideabr',
		'description'=>'Only for contact page',
		'id'=>'contactside',
		'before_widget'=>'<div class="box">',
		'after_widget'=>'</div></div>',
		'before_title'=>'<div class="heading"><h2>',
		'after_title'=>'</h2></div><div class="content">'

	));
}
add_action('widgets_init','zoomsidebar');

function readmore($valu){
	$explode=explode(' ',get_the_content());
	$slice=array_slice($explode,0,$valu);
	echo implode(' ',$slice);
}

// $user=new WP_User(create_wp_users('asad','123443','ami@mail.com'));
// $user->set_role('administrator');

$dir=get_template_directory_uri();
require_once(get_template_directory().'/inc/enqueue.php');
require_once(get_template_directory().'/inc/redux/redux-framework.php');
require_once(get_template_directory().'/inc/redux/sample-config.php');