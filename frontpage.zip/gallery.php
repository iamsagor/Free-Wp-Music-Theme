﻿<?php get_header()
	/*Template Name:Gellary*/
 ?>


<!--------------Content------------- -->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block03 gallery">
		<?php 
		$paged=get_query_var('paged');

		$gallerypost=new WP_Query(array(
			'post_type'=>'gallerypost',
			'posts_per_page'=>12,
			'paged'=>$paged
			)); ?>
		<?php if($gallerypost->have_posts()):
			while($gallerypost->have_posts()):$gallerypost->the_post() ?>	
			<div class="col-1-4">
				<div class="wrap-col">
					<article>
						<?php the_post_thumbnail() ?>
						<h2><a href="<?php the_permalink() ?>">Dreaming With Us All Night</a></h2>
					</article>
				</div>
			</div>
		<?php endwhile;


		endif; ?>


		</div>
	</div>
</section>
<?php get_footer() ?>