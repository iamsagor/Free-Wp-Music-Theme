<?php


function style_js(){
	wp_enqueue_style('bootstrap',get_template_directory_uri().'/css/bootstrap.css','','','all');
	wp_enqueue_style('mainstyle',get_template_directory_uri().'/css/style.css',array(),'1.0.1','all');
	wp_enqueue_style('rescss',get_template_directory_uri().'/css/responsive.css',array(),'1.0.1','all');
	wp_enqueue_style('slidecss',get_template_directory_uri().'/css/responsiveslides.css',array(),'1.0.1','all');
	wp_enqueue_style('zerogrid',get_template_directory_uri().'/css/zerogrid.css',array(),'1.0.1','all');




	wp_enqueue_script('css3',get_template_directory_uri().'/js/css3-mediaqueries.js',array('jquery'),'1.0.1','all');
	wp_enqueue_script('html5',get_template_directory_uri().'/js/html5.js',array('jquery'),'1.0.1','all');
	wp_enqueue_script('jquery',get_template_directory_uri().'/js/jquery.min.js',array('jquery'),'1.0.1','all');
	wp_enqueue_script('responsive',get_template_directory_uri().'/js/responsiveslides.js',array('jquery'),'1.0.1','all');
}
add_action('wp_enqueue_scripts','style_js');
?>