﻿
<?php get_header() ?>
<! - -------------Content------------- -->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block03">
			<div class="col-2-3">
				<div class="wrap-col">

					<?php while(have_posts()):the_post() ?>

					<article>
						<?php 
								if ( has_post_thumbnail() ) {
								    the_post_thumbnail();
								}
								else {
								    echo '<img src="' . get_bloginfo( 'stylesheet_directory' ) 
								        . '/images/thumbnail-default.jpg" />';
								}
							?>
						<h2><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h2>
						<div class="info">[By <?php the_author() ?> on <?php the_time('F d,Y') ?> with <a href="#"><?php comments_popup_link( false,''); ?></a>]</div>
						<?php readmore(20) ?>....... <a href="<?php the_permalink(); ?>">ReadMore</a>
					</article>
					<?php endwhile; ?>
					<ul id="pagi">
						<?php echo paginate_links() ?>
					</ul>
					
				</div>
			</div>
			<div class="col-1-3">
				<div class="wrap-col">
					<?php dynamic_sidebar('rightside') ?>
			</div>
		</div>
	</div>
</section>
<?php get_footer() ?>