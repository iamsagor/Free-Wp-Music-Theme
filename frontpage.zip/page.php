<?php get_header() ?>

<!- -------------Content------------- -->
<section id="content">
	<div class="wrap-content zerogrid">
		<div class="row block03">
			<div class="col-3-3">
				<div class="wrap-col">

				<?php 
					
					 while(have_posts()):the_post() ?>
						<article>
							<?php the_post_thumbnail() ?>
							<h2><?php the_title() ?></h2>
							<div class="info">[By <?php the_author(); ?> on <?php the_time('M d Y g:i a') ?> with <?php comments_popup_link('no cmnt','1 cmnt','% comments','','') ?>]</div>
							<p><?php the_content() ?></p>												
						</article>
				<?php endwhile;?>
				<?php 
					$paged= get_query_var('paged');
					$kisupost= new WP_Query(array(
						'post_type'=>'post',
						'posts_per_page'=>3,
						'paged'=>$paged
					));
					if($kisupost->have_posts()):
						while($kisupost->have_posts()):$kisupost->the_post()?>
						<a href="<?php the_permalink(); ?>"><?php the_title() ?></a><br>
					<?php endwhile;
					endif;

				 ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer() ?>