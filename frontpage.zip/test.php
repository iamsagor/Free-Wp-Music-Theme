<?php get_header(); /*Template Name:Test Page*/?>
 			

<div class="postpage">
	<?php 
		$pageq=get_query_var('paged');
		$postpager= new WP_Query(array(
		'page_name'=>'blog',
		'posts_per_page'=>3,
		'paged'=>$pageq
		)) ?>
	<?php 
	if(have_posts()) :
		while($postpager->have_posts()):
			$postpager->the_post()?>
			<div class="onepost">
				<h1><a href="<?php the_permalink(  ); ?>"><?php the_title() ?></a></h1>
				<p><?php readmore(20) ?><a href="<?php the_permalink(  ); ?>">Read More....</a></p>
			</div>
	<?php endwhile;
		echo paginate_links(array(
			'total'=>$postpager->max_num_pages
		));
	endif; ?>



</div>

<section>
	<?php 
		$album=new WP_Query(array(
			'post_type'=>'albumpic',
			'posts_per_page'=>3
		));
		while($album->have_posts()):$album->the_post()?>
	<div class="col-md-4"><?php the_post_thumbnail() ?></div>
	<?php endwhile; ?>
</section>

 

<?php get_footer() ?>








